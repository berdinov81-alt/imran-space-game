const fs=require('node:fs'),path=require('node:path'),{spawnSync}=require('node:child_process');
const platform=process.argv[2];
if(!['android','ios'].includes(platform))throw Error('Use android or ios');
const cliPackage=require.resolve('@capacitor/cli/package.json'),pkg=require(cliPackage),cli=path.resolve(path.dirname(cliPackage),typeof pkg.bin==='string'?pkg.bin:pkg.bin.cap);
const run=args=>{const result=spawnSync(process.execPath,[cli,...args],{cwd:__dirname,stdio:'inherit',windowsHide:true});if(result.status!==0)throw Error('Capacitor step failed: '+args.join(' '));};
const edit=(file,change)=>{const name=path.join(__dirname,file);fs.writeFileSync(name,change(fs.readFileSync(name,'utf8')));};
async function prepare(){
 await require('./build.cjs')();
 if(!fs.existsSync(path.join(__dirname,platform)))run(platform==='ios'?['add','ios','--packagemanager','SPM']:['add','android']);
 run(['sync',platform]);
 if(platform==='android'){
  edit('android/app/src/main/AndroidManifest.xml',xml=>xml.includes('android:screenOrientation=')?xml:xml.replace('<activity','<activity android:screenOrientation="portrait"'));
  edit('android/app/build.gradle',text=>text.replace(/versionCode \d+/,'versionCode 400').replace(/versionName "[^"]+"/,'versionName "4.0.0"'));
  for(const [name,size] of [['mdpi',192],['hdpi',192],['xhdpi',192],['xxhdpi',512],['xxxhdpi',512]]){
   const folder=path.join(__dirname,'android/app/src/main/res','mipmap-'+name);
   fs.mkdirSync(folder,{recursive:true});
   for(const file of ['ic_launcher.png','ic_launcher_round.png','ic_launcher_foreground.png'])fs.copyFileSync(path.join(__dirname,'../app-icon-'+size+'.png'),path.join(folder,file));
  }
  const resources=path.join(__dirname,'android/app/src/main/res');
  for(const folder of fs.readdirSync(resources)){const file=path.join(resources,folder,'splash.png');if(fs.existsSync(file))fs.copyFileSync(path.join(__dirname,'splash-portrait.png'),file);}
  edit('android/app/src/main/res/values/ic_launcher_background.xml',text=>text.replace(/#[0-9a-fA-F]{6}/g,'#050B16'));
  edit('android/app/src/main/res/values/styles.xml',text=>text.includes('windowSplashScreenBackground')?text:text.replace('<item name="android:background">@drawable/splash</item>','<item name="android:background">@drawable/splash</item>\n        <item name="windowSplashScreenBackground">#050B16</item>\n        <item name="windowSplashScreenAnimatedIcon">@mipmap/ic_launcher</item>\n        <item name="postSplashScreenTheme">@style/AppTheme.NoActionBar</item>'));
 }else{
  edit('ios/App/App/Info.plist',xml=>{
   xml=xml.replace(/(<key>UISupportedInterfaceOrientations<\/key>\s*)<array>[\s\S]*?<\/array>/,'$1<array><string>UIInterfaceOrientationPortrait</string></array>');
   xml=xml.replace(/(<key>UISupportedInterfaceOrientations~ipad<\/key>\s*)<array>[\s\S]*?<\/array>/,'$1<array><string>UIInterfaceOrientationPortrait</string></array>');
   xml=xml.replace(/<key>UIRequiresFullScreen<\/key>\s*<true\/>/g,'');
   return xml.replace(/<\/dict>\s*<\/plist>/,'<key>UIRequiresFullScreen</key><true/>\n</dict>\n</plist>');
  });
  edit('ios/App/App.xcodeproj/project.pbxproj',text=>text.replace(/CURRENT_PROJECT_VERSION = \d+;/g,'CURRENT_PROJECT_VERSION = 400;').replace(/MARKETING_VERSION = [^;]+;/g,'MARKETING_VERSION = 4.0.0;'));
  const icons=path.join(__dirname,'ios/App/App/Assets.xcassets/AppIcon.appiconset');
  fs.mkdirSync(icons,{recursive:true});
  fs.copyFileSync(path.join(__dirname,'../app-icon-1024.png'),path.join(icons,'AppIcon-1024.png'));
  fs.writeFileSync(path.join(icons,'Contents.json'),JSON.stringify({images:[{filename:'AppIcon-1024.png',idiom:'universal',platform:'ios',size:'1024x1024'}],info:{author:'xcode',version:1}},null,2));
  const splash=path.join(__dirname,'ios/App/App/Assets.xcassets/Splash.imageset');
  fs.copyFileSync(path.join(__dirname,'splash-portrait.png'),path.join(splash,'imran-splash.png'));
  fs.writeFileSync(path.join(splash,'Contents.json'),JSON.stringify({images:[{filename:'imran-splash.png',idiom:'universal'}],info:{author:'xcode',version:1}},null,2));
 }
 console.log(platform+' project prepared. Device builds and signing use the platform SDK.');
}
prepare().catch(error=>{console.error(error);process.exitCode=1;});
