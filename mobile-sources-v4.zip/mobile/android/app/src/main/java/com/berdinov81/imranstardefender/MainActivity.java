package com.berdinov81.imranstardefender;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
