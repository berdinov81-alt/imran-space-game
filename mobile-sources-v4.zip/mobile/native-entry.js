import { Capacitor } from '@capacitor/core';
import { App } from '@capacitor/app';
import { Haptics, ImpactStyle, NotificationType } from '@capacitor/haptics';
import '../native.js';
if(Capacitor.isNativePlatform()){
 App.addListener('appStateChange',({isActive})=>{if(!isActive){window.ImranCampaign.profile.save();document.dispatchEvent(new CustomEvent('imran:pause'));}});
 App.addListener('backButton',()=>{const visible=id=>!document.getElementById(id).classList.contains('hidden');if(visible('top')){if(visible('pauseMenu'))document.getElementById('resumeBtn').click();else document.dispatchEvent(new CustomEvent('imran:pause'));}else if(!visible('start'))document.getElementById('resultMenu').click();else if(!visible('homePage'))document.getElementById('homeBtn').click();else App.exitApp();});
 document.addEventListener('imran:haptic',event=>{if(!window.ImranCampaign.profile.state.settings.vibration)return;const operation=event.detail?.kind==='damage'?Haptics.notification({type:NotificationType.Warning}):Haptics.impact({style:event.detail?.kind==='pulse'?ImpactStyle.Medium:ImpactStyle.Light});operation.catch(()=>{});});
}
