const fs=require('node:fs'),path=require('node:path'),esbuild=require('esbuild');
const root=path.resolve(__dirname,'..'),target=path.join(__dirname,'www');
const files=['index.html','privacy.html','THIRD_PARTY_NOTICES.txt','campaign.js','lobby.js','game.js','styles.css','menu-v3.png','pilot-v2.png','nebula-v2.png','aliens-v2.png','bosses-v4.png','face.jpg','app-icon.svg','app-icon-192.png','app-icon-512.png','app-icon-1024.png','manifest.webmanifest'];
async function build(){
 fs.mkdirSync(target,{recursive:true});
 for(const file of files)fs.copyFileSync(path.join(root,file),path.join(target,file));
 // Read modules through Node so packaging also works in restricted desktop workspaces.
 const localModules={name:'local-modules',setup(builder){
  builder.onResolve({filter:/.*/},args=>{
   const base=args.importer&&path.isAbsolute(args.importer)?path.dirname(args.importer):__dirname;
   let resolved;
   if(args.path.startsWith('.')){const candidate=path.resolve(base,args.path);resolved=[candidate,candidate+'.js',path.join(candidate,'index.js')].find(file=>fs.existsSync(file)&&fs.statSync(file).isFile());if(!resolved)throw Error('Missing module: '+candidate);}
   else{
    const packagePath=require.resolve(args.path+'/package.json',{paths:[base]});
    const packageInfo=JSON.parse(fs.readFileSync(packagePath,'utf8'));
    resolved=path.resolve(path.dirname(packagePath),packageInfo.module||packageInfo.main);
   }
   return {path:resolved,namespace:'local-source'};
  });
  builder.onLoad({filter:/.*/,namespace:'local-source'},args=>({contents:fs.readFileSync(args.path,'utf8'),loader:'js'}));
 }};
 const result=await esbuild.build({stdin:{contents:fs.readFileSync(path.join(__dirname,'native-entry.js'),'utf8'),sourcefile:'native-entry.js',loader:'js'},plugins:[localModules],bundle:true,platform:'browser',format:'iife',target:['safari15','chrome100'],write:false,minify:true});
 fs.writeFileSync(path.join(target,'native.js'),result.outputFiles[0].contents);
 console.log('Native web bundle ready: '+target);
}
module.exports=build;
if(require.main===module)build().catch(error=>{console.error(error);process.exitCode=1;});
